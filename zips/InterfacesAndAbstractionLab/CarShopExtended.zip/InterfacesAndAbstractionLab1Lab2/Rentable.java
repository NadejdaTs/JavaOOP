package InterfacesAndAbstractionLab1Lab2;

public interface Rentable extends Car{
    Integer getMinRentDay();
    Double getPricePerDay();

}
