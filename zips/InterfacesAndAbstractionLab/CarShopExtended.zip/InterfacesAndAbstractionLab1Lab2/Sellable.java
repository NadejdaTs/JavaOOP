package InterfacesAndAbstractionLab1Lab2;

public interface Sellable extends Car{
    Double getPrice();
}
