package InterfacesAndAbstractionLab5;

public interface Identifiable {
    String getId();
}
