package InterfacesAndAbstractionLab3Lab4;

public interface Person {
    String getName();
    String sayHello();
}
