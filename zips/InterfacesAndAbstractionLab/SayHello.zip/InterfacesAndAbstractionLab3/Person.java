package InterfacesAndAbstractionLab3;

public interface Person {
    String getName();
    String sayHello();
}
