package InterfacesAndAbstractionLab6;

public interface Car {
    String breaks();
    String gas();
}
