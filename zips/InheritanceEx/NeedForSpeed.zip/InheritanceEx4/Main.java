package InheritanceEx4;

public class Main {
}
