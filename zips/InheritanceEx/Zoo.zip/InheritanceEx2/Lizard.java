package InheritanceEx2;

public class Lizard extends Reptile{

    public Lizard(String name){
        super(name);
    }
}
