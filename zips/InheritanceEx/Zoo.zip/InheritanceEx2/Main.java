package InheritanceEx2;

public class Main {
}
