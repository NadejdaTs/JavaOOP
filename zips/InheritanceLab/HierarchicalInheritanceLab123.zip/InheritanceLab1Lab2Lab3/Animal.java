package InheritanceLab1Lab2Lab3;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
