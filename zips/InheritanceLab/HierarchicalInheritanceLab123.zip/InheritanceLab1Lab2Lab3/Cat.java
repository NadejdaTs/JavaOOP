package InheritanceLab1Lab2Lab3;

public class Cat extends Animal{
    public void meow(){
        System.out.println("meowing...");
    }
}
