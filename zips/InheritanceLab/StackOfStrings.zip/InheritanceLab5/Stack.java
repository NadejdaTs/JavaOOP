package InheritanceLab5;

import java.util.ArrayDeque;

public class Stack {
    private ArrayDeque<String> data;


}
