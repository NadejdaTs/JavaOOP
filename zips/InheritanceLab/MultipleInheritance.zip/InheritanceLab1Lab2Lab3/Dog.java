package InheritanceLab1Lab2Lab3;

public class Dog extends Animal{
    public void bark(){
        System.out.println("barking...");
    }
}
