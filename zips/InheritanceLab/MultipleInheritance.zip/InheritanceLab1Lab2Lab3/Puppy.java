package InheritanceLab1Lab2Lab3;

public class Puppy extends Dog{
    public void weep(){
        System.out.println("weeping...");
    }
}
