package WorkingWithAbstractionLab3;

public class ConsolePrinter {
    public static void printLine(String result){
        System.out.println(result);
    }
}
