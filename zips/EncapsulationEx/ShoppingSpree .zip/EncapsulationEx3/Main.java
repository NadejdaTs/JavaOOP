package EncapsulationEx3;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*Scanner sc = new Scanner(System.in);
        String[] inputPerson = sc.nextLine().split(";");

        for (int i = 0; i < inputPerson.length; i++) {
            String[] token = inputPerson[i].split("=");
            Person person = new Person(token[0], Double.parseDouble(token[1]));
        }

        String[] inputProducts = sc.nextLine().split(";");

        for (int i = 0; i < inputProducts.length; i++) {
            String[] token = inputProducts[i].split("=");
            Product product = new Product(token[0], Double.parseDouble(token[1]));
        }

        String[] input = sc.nextLine().split("\\s+");
        while(!input[0].equals("END")){
            String name = input[0];
            person.setName(name).buyProduct(input[1])
            input = sc.nextLine().split("\\s+");
        }*/
    }
}
