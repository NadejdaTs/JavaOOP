package InterfacesAndAbstractionEx1Ex2;

public interface Person {
    String getName();
    int getAge();
}
