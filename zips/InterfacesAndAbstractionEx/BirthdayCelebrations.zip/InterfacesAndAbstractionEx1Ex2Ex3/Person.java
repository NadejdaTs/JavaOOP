package InterfacesAndAbstractionEx1Ex2Ex3;

public interface Person {
    String getName();
    int getAge();
}
