package InterfacesAndAbstractionEx1Ex2Ex3;

public interface Identifiable {
    String getId();
}
