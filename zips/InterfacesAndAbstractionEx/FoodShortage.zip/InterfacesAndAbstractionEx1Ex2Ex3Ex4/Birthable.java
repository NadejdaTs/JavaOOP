package InterfacesAndAbstractionEx1Ex2Ex3Ex4;

public interface Birthable {
    String getBirthDate();
}
