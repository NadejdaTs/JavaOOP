package InterfacesAndAbstractionEx1Ex2Ex3Ex4;

public interface Identifiable {
    String getId();
}
