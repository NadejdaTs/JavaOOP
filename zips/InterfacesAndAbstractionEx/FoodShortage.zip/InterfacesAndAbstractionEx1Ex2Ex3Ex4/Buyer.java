package InterfacesAndAbstractionEx1Ex2Ex3Ex4;

public interface Buyer extends Person{
    void buyFood();
    int getFood();
}
