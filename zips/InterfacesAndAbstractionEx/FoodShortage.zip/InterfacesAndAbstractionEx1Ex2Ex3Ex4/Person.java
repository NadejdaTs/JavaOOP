package InterfacesAndAbstractionEx1Ex2Ex3Ex4;

public interface Person {
    String getName();
    int getAge();
}
